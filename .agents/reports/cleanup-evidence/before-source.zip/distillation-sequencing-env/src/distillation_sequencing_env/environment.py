"""
Last modified time: 2026-09-24
Last modified content: Centralize deterministic chemical transitions for four algorithms
Last modified by: OpenAI Codex
File design: Pure state functions with a stateful episode wrapper
File purpose: Calculate costs, legal actions, action masks, and sharp-split transitions
File creator: OpenAI Codex
"""

from __future__ import annotations

from collections.abc import Iterable

from distillation_sequencing_env.data import (
    COLUMN_BY_ACTION,
    COMPONENT_MOLE_FRACTIONS,
    INITIAL_STATE,
    INTERMEDIATE_MIXTURES,
    MIXTURE_ORDER,
    TERMINAL_STATE,
    TOTAL_FEED_KMOL_PER_HOUR,
    TOTAL_UTILITY_COST,
)
from distillation_sequencing_env.models import ActionMask, ColumnEconomics, State, StepInfo, StepResult


def _validate_state(state: State) -> None:
    """Validate that a state is a six-element binary tuple.

    Inputs:
        state: Environment state to validate.
    Returns:
        None. Raises ValueError when the state is invalid.
    """

    if len(state) != len(MIXTURE_ORDER):
        raise ValueError("状态必须包含6个元素。")

    if any(value not in (0, 1) for value in state):
        raise ValueError("状态元素必须是0或1。")


def encode_state(active: Iterable[str]) -> State:
    """Encode active mixed streams as a six-element state.

    Inputs:
        active: Names of mixed streams that still require separation.
    Returns:
        A binary state ordered by the fixed stream convention.
    """

    mixtures = tuple(active)
    unknown = set(mixtures) - INTERMEDIATE_MIXTURES
    if unknown:
        raise ValueError(f"未知混合物流: {sorted(unknown)}")

    if len(mixtures) != len(set(mixtures)):
        raise ValueError("活跃混合物流不能重复。")

    return tuple(int(name in mixtures) for name in MIXTURE_ORDER)  # type: ignore[return-value]


def active_mixtures(state: State) -> tuple[str, ...]:
    """Decode a six-element state into active mixed streams.

    Inputs:
        state: Six-element binary environment state.
    Returns:
        Active mixed-stream names in the fixed stream order.
    """

    _validate_state(state)
    return tuple(name for name, is_active in zip(MIXTURE_ORDER, state) if is_active)


def available_actions(state: State) -> tuple[int, ...]:
    """Return all textbook column IDs that are feasible in a state.

    Inputs:
        state: Six-element binary environment state.
    Returns:
        Feasible action IDs in ascending order.
    """

    active = set(active_mixtures(state))
    return tuple(
        action_id
        for action_id, column in COLUMN_BY_ACTION.items()
        if column.feed_mixture in active
    )


def action_mask(state: State) -> ActionMask:
    """Build a Boolean mask for textbook action IDs 1 through 10.

    Inputs:
        state: Six-element binary environment state.
    Returns:
        A length-10 mask whose index equals the action ID minus one.
    """

    valid = set(available_actions(state))
    return tuple(action_id in valid for action_id in range(1, 11))  # type: ignore[return-value]


def calculate_column_economics(action_id: int) -> ColumnEconomics:
    """Calculate flow, heat duty, and cost from the textbook equations.

    Inputs:
        action_id: Textbook column ID in the range 1 through 10.
    Returns:
        ColumnEconomics expressed with the textbook scaling conventions.
    """

    if action_id not in COLUMN_BY_ACTION:
        raise ValueError(f"未知动作编号: {action_id}")

    column = COLUMN_BY_ACTION[action_id]
    mole_fraction = sum(COMPONENT_MOLE_FRACTIONS[item] for item in column.feed_mixture)
    feed_flow = TOTAL_FEED_KMOL_PER_HOUR * mole_fraction
    heat_duty = column.heat_duty_coefficient * feed_flow
    annual_cost = (
        column.fixed_cost_kusd_per_year
        + column.variable_cost_factor * feed_flow
        + TOTAL_UTILITY_COST * heat_duty
    )
    return ColumnEconomics(feed_flow, heat_duty, annual_cost, annual_cost / 1000.0)


def apply_action(state: State, action_id: int) -> State:
    """Apply one feasible deterministic sharp split to a state.

    Inputs:
        state: Six-element state before the action.
        action_id: Candidate column ID from the textbook.
    Returns:
        The next state after replacing the feed with non-pure products.
    """

    valid = available_actions(state)
    if action_id not in COLUMN_BY_ACTION:
        raise ValueError(f"未知动作编号: {action_id}")

    if action_id not in valid:
        raise ValueError(f"动作 {action_id} 在当前状态不可行。")

    column = COLUMN_BY_ACTION[action_id]
    next_active = set(active_mixtures(state)) - {column.feed_mixture}
    next_active.update(
        product
        for product in (column.light_product, column.heavy_product)
        if product in INTERMEDIATE_MIXTURES
    )
    return encode_state(next_active)


class DistillationSequenceEnvironment:
    """Manage one deterministic four-component separation episode.

    Inputs:
        None. The environment always starts from the textbook ABCD feed.
    Returns:
        States, rewards, masks, and engineering details through reset and step.
    """

    def __init__(self) -> None:
        """Initialize the environment state and episode records.

        Inputs:
            None.
        Returns:
            None. Creates the initial state, zero cost, and empty action history.
        """

        self._state = INITIAL_STATE
        self._cumulative_cost = 0.0
        self._selected_actions: list[int] = []

    def reset(self) -> tuple[State, ActionMask]:
        """Restore the environment to the unseparated ABCD feed.

        Inputs:
            None.
        Returns:
            The initial six-element state and its action mask.
        """

        self._state = INITIAL_STATE
        self._cumulative_cost = 0.0
        self._selected_actions = []
        return self._state, action_mask(self._state)

    def step(self, action_id: int) -> StepResult:
        """Execute one feasible column and return a complete step result.

        Inputs:
            action_id: Textbook column ID in the range 1 through 10.
        Returns:
            StepResult containing the next state, reward, status, and economics.
        """

        if self._state == TERMINAL_STATE:
            raise RuntimeError("episode 已终止；请先调用 reset。")

        column = COLUMN_BY_ACTION.get(action_id)
        if column is None:
            raise ValueError(f"未知动作编号: {action_id}")

        economics = calculate_column_economics(action_id)
        self._state = apply_action(self._state, action_id)
        self._cumulative_cost += economics.annual_cost_musd_per_year
        self._selected_actions.append(action_id)
        selection_vector = tuple(
            int(candidate in self._selected_actions)
            for candidate in range(1, 11)
        )
        info = StepInfo(
            action_id,
            column.feed_mixture,
            economics,
            self._cumulative_cost,
            tuple(self._selected_actions),
            selection_vector,
        )
        return StepResult(
            self._state,
            -economics.annual_cost_musd_per_year,
            self._state == TERMINAL_STATE,
            action_mask(self._state),
            info,
        )
