"""
Last modified time: 2026-09-24
Last modified content: Forward the chemical models to the shared package
Last modified by: OpenAI Codex
File design: Compatibility exports for the established distillation_ppo import path
File purpose: Preserve callers while all learners use one chemical environment
File creator: OpenAI Codex
"""

from __future__ import annotations

from dataclasses import dataclass

from distillation_sequencing_env.models import (
    ActionMask,
    ColumnEconomics,
    ColumnSpec,
    State,
    StepInfo,
    StepResult,
)


@dataclass(frozen=True)
class EvaluationResult:
    """Store the result of one deterministic greedy evaluation.

    Inputs:
        Final state, selected columns, selection vector, cost, and total reward.
    Returns:
        An immutable record of the evaluated pure distillation strategy.
    """

    final_state: State
    action_sequence: tuple[int, ...]
    normalized_column_set: tuple[int, ...]
    selection_vector: tuple[int, ...]
    total_cost_musd_per_year: float
    total_reward: float
